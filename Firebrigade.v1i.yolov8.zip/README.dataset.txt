# Fire engine > 2025-10-30 4:16pm
https://universe.roboflow.com/rajiv-fmfoj/fire-engine-ltetb

Provided by a Roboflow user
License: CC BY 4.0


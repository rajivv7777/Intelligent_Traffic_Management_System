# Ambulance  > 2025-10-30 3:21pm
https://universe.roboflow.com/rajiv-fmfoj/ambulance-xmkgm-jvtwi

Provided by a Roboflow user
License: CC BY 4.0


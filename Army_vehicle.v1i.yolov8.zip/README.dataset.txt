# Army vehicle > 2025-10-30 9:53pm
https://universe.roboflow.com/rajiv-fmfoj/army-vehicle-xa53z-rdifz

Provided by a Roboflow user
License: CC BY 4.0

